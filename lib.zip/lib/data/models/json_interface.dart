class JsonInterface {
  Map<String, dynamic> toJson() => {};
}