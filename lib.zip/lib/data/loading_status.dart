enum LoadingStatus {
  loading,
  error,
  success,
}
